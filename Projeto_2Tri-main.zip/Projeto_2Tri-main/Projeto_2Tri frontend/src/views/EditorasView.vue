<template>
  <main>
      <div class="prin-editoras">
          <div>
            <h1 class="tit-editoras"> Editoras </h1>
          </div>
          <div class="logos">
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <img class="logo" src="@/assets/imgs/SaraivaLogo.png" />
            <RouterLink to="/Cad_Editoras"> <img class="add" src="@/assets/imgs/Adicionar.png" /> </RouterLink>
          </div>
      </div>
  </main>
</template>

<style>
.prin-editoras {
    margin: 55px 150px;
    padding: 30px;
    box-shadow: 0 16px 40px 0.1px rgb(149, 149, 149);
    background-image: linear-gradient(to bottom right, rgb(240, 240, 240), rgb(255, 255, 255));
    border-radius: 5px;
}

.tit-editoras {
    font-family: 'Poppins';
    font-size: 50px;
    font-weight: 400;
    text-align: center;
    color: #616fee;
}

.logo {
    margin: 29px;
}

.add {
    padding: 10px;
}
</style>